KADER
=====
"bir hayat, senin elinde degil. elinde sadece tesaduf var."
"a life is not in your hands. all you hold are coincidences."

retroISTANBUL 2026 - Amstrad CPC Game Compo entry
by Tulip / Asko Kusko (Sueda & Yusuf), designed with Claude (Anthropic)


--------------------------------------------------------------- ENGLISH

WHAT IS IT
A life simulation. A character is born from a DNA and lives from 2000
(age 18) until old age. The character decides WHAT to do (by its genes);
you are fate: you decide HOW it ends. Every event ends with
  1 KAZANDI (won)   2 KAYBETTI (lost)   3 [die icon] (pure 50/50 chance)
Winning is not always good: the effect depends on the moment, on the
hidden DNA, on earlier choices and on the system's own dice.
At the end the life is woven into a kilim (a Turkish rug) with the
"life melody", and the whole hidden DNA is revealed.

TECHNICAL
  Machine   : Amstrad CPC 6128 (main target, tested in emulator from the
              disc). Also runs on a CPC 464 (BASIC 1.0) with a DDI-1 disc
              drive: tested in emulator as 464 ROMs + AMSDOS disc ROM,
              reading the same disc. Uses no 6128-only commands. The game
              reads its event files from the disc while playing, so keep
              the disc in the drive. CPC 664 not tested.
  Memory    : 64 KB is enough (main RAM only, no extra banks).
  Format    : kader.dsk, standard CPCEMU DATA format disc.
  Events    : version 2: 82 events, 142 small moments, 45 seeds/echoes,
              every outcome has 4 texts. The events live on the
              disc in one file per decade (D2000.DAT ... D2040.DAT, index
              and small moments, read at each decade start) and small
              text files (E2000A.DAT ...) read when an event comes.
  Language  : Locomotive BASIC, MODE 1, firmware font + redefined dice
              characters (SYMBOL). Sound: AY chip via SOUND.
  Text      : Turkish, written without Turkish-specific letters
              (KIVILCIM, YAS 22) like the computer screens of the time.

START
  Insert kader.dsk and type:   RUN"KADER     then press RETURN.
  Loading takes a few seconds.

CONTROLS (keyboard only)
  Title      1 = 2000'LER (life) mode. SOYUT and GEZEGEN are "YAKINDA"
             (coming soon).
  DNA        1 KIVILCIM ("jumps first, thinks later")
             2 KOK ("bonds deeply, breaks late")
             3 [die] random DNA; 3 again = roll again, RETURN = accept.
             (Some say a lucky one hides behind the die.)
  Face       1-3 choose a face, 4 [die] = random face.
             The face has a hidden effect on life, skin colour has none.
  Event      The card shows what happens and what the character wants
             ("> wants to meet"). You have 12 KADER (fate) points:
               1 TESADUF EKLE  add a coincidence: it happens anyway
               2 KAPIYI KAPAT  close the door: it does not happen
               3 FISILDA       whisper: maybe it changes its mind
               SPACE           just watch
  Outcome    1 KAZANDI  2 KAYBETTI  3 [die] = 50/50, the die is never
             bent by luck.
  Messages   Any key continues (or wait a few seconds).
  End        SPACE = a new life.

HOW TO PLAY
  - Genes start hidden (?). You learn them from behaviour: first a hint
    (arrow up/down), later the number. Big events change genes.
  - Some events leave seeds. Years later an orange "YANKI" (echo) banner
    tells you which old event shaped today, and whose decision it was:
    your coincidence, your door, your whisper, your decision, or the die's.
  - The small die in the top-right corner is the system's die. The word
    under it says what it is rolled for (OLAY, GUNLER, YAS, ...). The
    hidden SANS (luck) gene bends only these system dice.
  - Bars: MUTLULUK happiness, SAGLIK health, BAG bonds, IZ the mark you
    leave. The HAYAT strip shows every year you lived.
  - Music only plays at the very end, while the kilim is woven.
  - One life takes about 10-20 minutes.

CREDITS AND THIRD-PARTY MATERIAL
  - Game code, texts, characters and dice graphics: original work by
    Tulip / Asko Kusko (Sueda & Yusuf), designed and written with Claude
    (Anthropic). Motifs follow traditional Anatolian kilim symbols.
  - In the game only the CPC's own firmware font (in ROM) is used.
  - Development tools only, NOT part of the game:
      * cpcfont.bin (CPC 6128 ROM character set, (c) Amstrad /
        Locomotive Software, distributed with Amstrad's ROM permission)
        was used to draw the concept screens.
      * floooh/chips (zlib licence, (c) Andre Weissflog) was used to build
        a headless CPC 6128 emulator for automatic play tests and the
        screenshots. CPC ROM images in that tool come with chips-test.
  - Screenshots in screenshots/ were taken from that emulator running
    kader.dsk.


--------------------------------------------------------------- TURKCE

NEDIR
Bir hayat simulasyonu. Karakter bir DNA'dan dogar, 2000'de 18 yasinda
baslar ve yaslilige kadar yasar. Ne yapacagina karakter (genleriyle)
karar verir; nasil sonuclanacagina sen, yani KADER karar verirsin. Her
olay su ekranla biter:
  1 KAZANDI   2 KAYBETTI   3 [zar ikonu] (saf sans, %50)
KAZANDI her zaman iyi degildir: etkisi o anki duruma, gizli DNA'ya,
onceki kararlara ve sistemin zarina baglidir. Sonda hayat bir kilime
dokunur, hayat melodisi calar ve butun DNA acilir.

TEKNIK
  Makine  : Amstrad CPC 6128 (ana hedef, emulatorde diskten test edildi).
            DDI-1 disket surucusu olan CPC 464'te de calisir (BASIC 1.0):
            emulatorde 464 ROM'lari + AMSDOS ile ayni diskten test edildi.
            6128'e ozel komut yok. Oyun olaylari oynarken diskten okur,
            disket surucude kalmali. CPC 664 test edilmedi.
  Olaylar : surum 2: 82 olay, 142 kucuk an, 45 tohum/yanki, her sonucun
            4 metni var. Olaylar diskte: her on yil icin bir dosya
            (D2000.DAT ... D2040.DAT, on yil basinda okunur) ve olay
            gelince okunan kucuk metin dosyalari (E2000A.DAT ...).
  Bellek  : 64 KB yeterli (yalniz ana bellek).
  Bicim   : kader.dsk (standart CPCEMU DATA disk).
  Dil     : Locomotive BASIC, MODE 1, ROM fontu + SYMBOL ile zar
            karakterleri. Ses: AY cipi (SOUND).
  Metin   : Turkce, noktasiz harflerle (KIVILCIM, YAS 22).

BASLATMA
  kader.dsk'yi tak, yaz:   RUN"KADER     ve RETURN'e bas (birkac saniye).

KONTROLLER (yalniz klavye)
  Baslik   1 = 2000'LER (hayat). SOYUT ve GEZEGEN: YAKINDA.
  DNA      1 KIVILCIM, 2 KOK, 3 [zar] rastgele DNA (tekrar 3 = yeni zar,
           RETURN = bu hayat). Zarin arkasinda sansli biri saklaniyor
           olabilir.
  Yuz      1-3 yuz sec, 4 [zar] rastgele yuz. Yuzun hayata etkisi
           gizlidir; ten renginin hicbir etkisi yoktur.
  Olay     Kartta olay ve karakterin niyeti ("> bulusmak istiyor").
           12 KADER puanin var:
             1 TESADUF EKLE  yine de olur
             2 KAPIYI KAPAT  olmaz
             3 FISILDA       belki fikrini degistirir
             BOSLUK          sadece izle
  Sonuc    1 KAZANDI  2 KAYBETTI  3 [zar] (%50, sans geni etkilemez)
  Bildirim Herhangi bir tus (ya da birkac saniye bekle).
  Son      BOSLUK = yeni hayat.

NASIL OYNANIR
  - Genler basta "?". Onu davranislarindan taniyacaksin: once ipucu
    (yukari/asagi ok), sonra sayi. Buyuk olaylar genleri degistirir.
  - Olaylar tohum birakir. Yillar sonra turuncu "YANKI" bandi hangi
    eski olayin bugunu etkiledigini ve kimin eseri oldugunu soyler.
  - Sag ustteki kucuk zar sistemin zaridir; altinda neye atildigi
    yazar. Gizli SANS geni yalniz bu zarlari etkiler.
  - MUTLULUK, SAGLIK, BAG, IZ gostergeleri; HAYAT seridi her yili
    gosterir. Muzik yalniz finalde, kilim dokunurken calar.
  - Bir hayat yaklasik 10-20 dakika surer.

ATIF
  Oyun kodu, metinler ve grafikler ozgundur: Tulip / Asko Kusko
  (Sueda & Yusuf), Claude (Anthropic) ile tasarlandi ve yazildi.
  Oyunda yalniz CPC'nin ROM fontu kullanilir. cpcfont.bin (Amstrad /
  Locomotive Software ROM fontu) yalniz konsept araclarinda, floooh/chips
  (zlib lisansi) yalniz test emulatorunde kullanildi; oyunun parcasi
  degildir.
