---
title: "cURL örnekleri"
product: genel
api_version: v1 (örnek)
last_updated: 2026-11-16
source_html: uc-noktalar.html
---

# cURL örnekleri

Swagger'daki 19 uç noktanın her biri için çalıştırmaya hazır iskelet. `{BASE_URL}` test ağ geçidi, `$KT_ACCESS_TOKEN` access token, `$KT_SIGNATURE` istek imzasıdır (../guides/istek-imzalama.md). Gövde alanları Swagger'da; burada uydurulmadı.

```bash
export KT_BASE_URL="https://prep-gateway.kuveytturk.com.tr"   # test, varsayılan
```

## Ödeme

### Ödeme başlatın

```bash
curl -X POST "{BASE_URL}/v1/vpos/digitalPaymentGetToken" \
  -H "Authorization: Bearer $KT_ACCESS_TOKEN" \
  -H "Signature: $KT_SIGNATURE" \
  -H "Content-Type: application/json" \
  -d @istek.json  # PostDigitalPaymentGetTokenBody
```

### Ödemeyi sorgulayın

```bash
curl -X POST "{BASE_URL}/v1/vpos/digitalPaymentQuery" \
  -H "Authorization: Bearer $KT_ACCESS_TOKEN" \
  -H "Signature: $KT_SIGNATURE" \
  -H "Content-Type: application/json" \
  -d @istek.json  # gövde şeması Swagger'da
```

### Belge gönderin

```bash
curl -X POST "{BASE_URL}/v1/vpos/sendDocument" \
  -H "Authorization: Bearer $KT_ACCESS_TOKEN" \
  -H "Signature: $KT_SIGNATURE" \
  -H "Content-Type: application/json" \
  -d @istek.json  # gövde şeması Swagger'da
```

### İade edin

> İnsan onayı olmadan çalıştırmayın (para hareketi).

```bash
curl -X POST "{BASE_URL}/v1/vpos/digitalPaymentDoRefund" \
  -H "Authorization: Bearer $KT_ACCESS_TOKEN" \
  -H "Signature: $KT_SIGNATURE" \
  -H "Content-Type: application/json" \
  -d @istek.json  # gövde şeması Swagger'da
```

## Finansman

### Finansmanları listeleyin

```bash
curl "{BASE_URL}/v1/loans" \
  -H "Authorization: Bearer $KT_ACCESS_TOKEN" \
  -H "Signature: $KT_SIGNATURE"
```

### Finansman ayrıntısı

```bash
curl "{BASE_URL}/v1/loans/{projectNumber}/info" \
  -H "Authorization: Bearer $KT_ACCESS_TOKEN" \
  -H "Signature: $KT_SIGNATURE"
```

### Taksit planı

```bash
curl "{BASE_URL}/v1/loans/{projectNumber}/installments" \
  -H "Authorization: Bearer $KT_ACCESS_TOKEN" \
  -H "Signature: $KT_SIGNATURE"
```

## Hesap verisi

### Hesap detayı

```bash
curl "{BASE_URL}/v2/accounts/{suffix}" \
  -H "Authorization: Bearer $KT_ACCESS_TOKEN" \
  -H "Signature: $KT_SIGNATURE"
```

### Hesap hareketleri (v2)

```bash
curl "{BASE_URL}/v2/accounts/{suffix}/transactions" \
  -H "Authorization: Bearer $KT_ACCESS_TOKEN" \
  -H "Signature: $KT_SIGNATURE"
```

### Hesap hareketleri (v3)

```bash
curl "{BASE_URL}/v3/accounts/{suffix}/transactions" \
  -H "Authorization: Bearer $KT_ACCESS_TOKEN" \
  -H "Signature: $KT_SIGNATURE"
```

### Dekont

```bash
curl -X POST "{BASE_URL}/v2/accounts/transactions/receipts" \
  -H "Authorization: Bearer $KT_ACCESS_TOKEN" \
  -H "Signature: $KT_SIGNATURE" \
  -H "Content-Type: application/json" \
  -d @istek.json  # gövde şeması Swagger'da
```

## Bilgi servisleri

### Döviz kurları

```bash
curl "{BASE_URL}/v1/fx/rates" \
  -H "Authorization: Bearer $KT_ACCESS_TOKEN" \
  -H "Signature: $KT_SIGNATURE"
```

### Döviz cinsleri

```bash
curl "{BASE_URL}/v1/data/fecs" \
  -H "Authorization: Bearer $KT_ACCESS_TOKEN" \
  -H "Signature: $KT_SIGNATURE"
```

### Şubeler

```bash
curl "{BASE_URL}/v1/data/branches" \
  -H "Authorization: Bearer $KT_ACCESS_TOKEN" \
  -H "Signature: $KT_SIGNATURE"
```

### Bankalar

```bash
curl "{BASE_URL}/v1/data/banks" \
  -H "Authorization: Bearer $KT_ACCESS_TOKEN" \
  -H "Signature: $KT_SIGNATURE"
```

### Bir bankanın şubeleri

```bash
curl "{BASE_URL}/v1/data/banks/{bankId}/branches" \
  -H "Authorization: Bearer $KT_ACCESS_TOKEN" \
  -H "Signature: $KT_SIGNATURE"
```

### ATM'ler

```bash
curl "{BASE_URL}/v1/data/atms" \
  -H "Authorization: Bearer $KT_ACCESS_TOKEN" \
  -H "Signature: $KT_SIGNATURE"
```

### Finansman verisi

```bash
curl "{BASE_URL}/v1/data/loans" \
  -H "Authorization: Bearer $KT_ACCESS_TOKEN" \
  -H "Signature: $KT_SIGNATURE"
```

## Test

### Test müşterilerini listeleyin

```bash
curl "{BASE_URL}/v1/data/testcustomers" \
  -H "Authorization: Bearer $KT_ACCESS_TOKEN" \
  -H "Signature: $KT_SIGNATURE"
```
