# AGENTS.md: Kuveyt Türk API paketi için ajan haritası

Bu klasör Kuveyt Türk API Market dokümanlarının Markdown paketidir (tasarım taslağı, API sürümü v1 örnek, 2026-11-16).
Projede genelde `docs/kuveytturk/` altında durur. Bu dosyayı ilk sen oku; sonra yalnız işine yarayan dosyayı aç.
Dosya boyutları ve yaklaşık token sayıları `manifest.json` içinde.

## Kurallar (her işte geçerli)

1. **Varsayılan ortam testtir.** `KT_BASE_URL` test ağ geçidini gösterir. Canlı adres ve canlı anahtarı kullanıcı açıkça vermedikçe kullanma, isteme.
2. **Para hareketinden önce dur.** İade (`POST /v1/vpos/digitalPaymentDoRefund`) ve para hareketi doğuran her çağrıdan önce kullanıcıdan açık onay al. Ödeme çağrılarını kör yeniden deneme; önce `POST /v1/vpos/digitalPaymentQuery` ile durumu sorgula.
3. **Uydurma uç nokta yok.** Uç nokta yolunu yalnız `reference/endpoints.md` ya da `openapi/kuveytturk-ornek.openapi.yaml` içinden al. Listede olmayan bir yol, alan adı ya da hata kodu yazma; bilinmeyen değeri `{değer}` gibi yer tutucuyla bırak ve kullanıcıya sor.
4. **Gizli bilgi yok.** Client secret, access token ve özel imza anahtarını koda, log'a, commit'e ya da sohbete yazma; ortam değişkeninden oku (`KT_BASE_URL`, `KT_CLIENT_ID`, `KT_CLIENT_SECRET`). T.C. kimlik numarası ve kart bilgisini log'a yazma.
5. **Her isteği imzala.** `Signature` başlığı: RSA-SHA256(access token + sorgu dizesi ya da gövde), base64. Ayrıntı `guides/istek-imzalama.md`.
6. **"Örnek" ve "Konsept" etiketlerine uy.** Örnek etiketli şemalar, hata kodları ve değişiklik kayıtları gerçek değildir; MCP sunucusu (`{KT_MCP_PAKETI}`) bugün yoktur.

## Hangi işte hangi dosya

| İş | Önce oku | Sonra |
|---|---|---|
| İlk kurulum, ilk istek | `guides/hizli-baslangic.md` | `guides/ortamlar.md`, `guides/uygulama-ve-anahtarlar.md` |
| Token ve imza hatası | `guides/istek-imzalama.md` | `reference/errors.md` |
| Kartla ödeme, iade | `products/odeme.md` | `reference/errors.md` (yeniden deneme) |
| Taksitli finansman | `products/finansman.md` | `products/bilgi-servisleri.md` (`/v1/data/loans`) |
| Hesap detayı, hareketler, dekont | `products/hesap-verisi.md` | `guides/test-musterileri.md` |
| Kur, şube, banka, ATM | `products/bilgi-servisleri.md` | |
| Yanıtı ayrıştırma | `reference/yanit-zarfi.md` | |
| Tüm uç noktalar | `reference/endpoints.md` | `openapi/kuveytturk-ornek.openapi.yaml` |
| Hızlı cURL denemesi | `examples/curl.md` | |
| Canlıya geçiş | `guides/canliya-gecis.md` | |
| Kurulum adımlarını kullanıcıya anlatma | `guides/kurulum-adimlari.md` | |

## Klasörler

- `guides/`: başlangıç, ortamlar, kimlik doğrulama, imza, canlıya geçiş, yapay zekâ ile kurulum (konsept)
- `products/`: Ödeme, Finansman, Hesap verisi, Bilgi servisleri; her uç nokta cURL, Node.js, Python ve C# örnekli
- `reference/`: uç nokta listesi, yanıt zarfı, hata kodları (örnek), değişiklik günlüğü (örnek)
- `openapi/`: yalnız gerçek yolları içeren örnek OpenAPI 3 şeması (alan adı içermez)
- `examples/`: cURL iskeletleri

## Bilinmeyenler

Bu taslakta doğrulanmamış olanlar yer tutucuyla yazıldı: `{BASE_URL}`, `{TOKEN_URL}`, `{kapsam}`, `{suffix}`, `{test_musteri_no}`, rate limit `{değer}`, Kuveyt Türk'e özgü hata kodları `{kod}`. Bunları tahmin etme; kullanıcıya ya da portaldaki Swagger'a başvur.
