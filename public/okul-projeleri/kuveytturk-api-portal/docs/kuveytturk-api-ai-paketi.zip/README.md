# Kuveyt Türk API AI paketi

Kuveyt Türk API Market dokümanlarının yapay zekâ araçları için hazırlanmış Markdown paketi (tasarım taslağı, API sürümü v1 örnek, 2026-11-16).
Tek dev dosya yerine küçük dosyalar: ajan önce `AGENTS.md` dosyasını okur, sonra yalnız gereken dosyayı açar.

## Projeye ekleme

```bash
curl -L https://hamaratlabs.com/okul-projeleri/kuveytturk-api-portal/docs/kuveytturk-api-ai-paketi.zip -o kt.zip && unzip kt.zip -d docs/kuveytturk
```

`https://hamaratlabs.com/okul-projeleri/kuveytturk-api-portal/docs` doküman sitesinin yayın adresidir. Paketi proje kökünde `docs/kuveytturk/` olarak açın.

## Araca tanıtma

**Claude Code.** Proje kökündeki `CLAUDE.md` dosyasına şu satırı ekleyin; Claude Code oturum başında dosyayı içeri alır:

```text
@docs/kuveytturk/AGENTS.md
```

Sonra şunu yapıştırın:

```text
docs/kuveytturk/AGENTS.md dosyasını oku ve oradaki kurallarla çalış.
Kuveyt Türk API entegrasyonunu test ortamında kur.
Uç nokta yollarını yalnız docs/kuveytturk/reference/endpoints.md ve
docs/kuveytturk/openapi/kuveytturk-ornek.openapi.yaml dosyalarından al;
listede olmayan bir uç nokta yazma.
Anahtarları ortam değişkeninden oku (KT_BASE_URL, KT_CLIENT_ID, KT_CLIENT_SECRET);
koda, log'a ya da sohbete yazma.
İade dahil her para hareketinden önce dur ve onayımı iste.
```

**Cursor.** `.cursor/rules/kuveytturk.mdc` gibi bir kural dosyası açın: "Kuveyt Türk işlerinde önce docs/kuveytturk/AGENTS.md dosyasını oku ve kurallarına uy."

**Codex.** Depo kökündeki `AGENTS.md` dosyasına aynı yönlendirmeyi ekleyin: "Kuveyt Türk API işleri için docs/kuveytturk/AGENTS.md dosyasını oku."

**ChatGPT.** Zip'i sohbete yükleyin ve "Önce AGENTS.md'yi oku" diye başlayın.

## İçerik ve doğrulama

- `manifest.json`: sürüm, tarih, her dosyanın boyutu, sha256 özeti ve yaklaşık token sayısı (karakter / 4).
- Doğrulama: `shasum -a 256 docs/kuveytturk/guides/hizli-baslangic.md` çıktısı manifest'teki değerle aynı olmalı.
- Her .md dosyasının YAML başlığında `title`, `product`, `api_version`, `last_updated`, `source_html` alanları vardır.

## Sınırlar

Bu bir tasarım taslağıdır. Uç nokta yolları API Market Swagger'ından alınmıştır; gövde ve yanıt alanları uydurulmamış, Swagger'a bırakılmıştır. "Örnek" etiketli içerik (hata kodları, değişiklik günlüğü, OpenAPI şemaları) gerçek değildir. MCP sunucusu konsepttir.
